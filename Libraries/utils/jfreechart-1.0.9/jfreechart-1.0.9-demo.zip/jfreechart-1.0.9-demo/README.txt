==================================
JFREECHART DEMO COLLECTION (1.0.8)
==================================

23 November 2007


1)  OVERVIEW
------------
This collection of JFreeChart demo applications includes:

    - all the source code for the demo application that is included in the
      JFreeChart distribution;
    - the source code for the JDBC and servlet demos described in the
      JFreeChart Developer Guide.
    - a few additional demos that you might also find helpful.

To run the main demo type:

    java -jar jfreechart-1.0.8-demo.jar

This collection is only available for download to purchasers of the JFreeChart
Developer Guide.  Thanks for supporting the JFreeChart project.


2)  THIRD PARTY LIBRARIES
-------------------------
The demo incorporates iText (version 2.0.6), a library for creating PDF files.  
iText is licensed under the terms of the GNU Lesser General Public Licence.  
You can download iText from:

    http://www.lowagie.com/iText/


3)  FEEDBACK
------------
If you have any comments about the JFreeChart demo collection, please send
an e-mail to:  

    david.gilbert@object-refinery.com.